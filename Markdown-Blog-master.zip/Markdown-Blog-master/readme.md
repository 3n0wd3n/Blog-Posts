<!-- 
BEFORE STARTED YOU MUST PUT THIS ON TERMINAL
npm i express mongoose ejs method-override
npm i --save-dev nodemo
npm run devStart 
-->